package com.bbhint;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import hint.Detector;
import hint.Piece;
import hint.Solver;

public class CaptureService extends Service {
    public static final String ACTION_STOP = "stop";
    private static final String CHANNEL = "bbhint";

    private final Handler main = new Handler(Looper.getMainLooper());
    private HandlerThread workThread;
    private Handler work;

    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay vdisplay;
    private WindowManager wm;
    private int sw, sh;

    private final Object frameLock = new Object();
    private Image held;

    private HintView hintView;
    private LinearLayout panel;
    private Button autoBtn;

    private volatile boolean autoOn;
    private Thread autoThread;

    private static final class Analysis {
        String error;
        Detector.Result res;
        Solver.Plan plan;
        Piece[] pieces;
        int[] slotOf;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null || ACTION_STOP.equals(in.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY;

        startFg();
        int code = in.getIntExtra("code", 0);
        Intent data = (Intent) in.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        if (projection == null) {
            stopSelf();
            return START_NOT_STICKY;
        }

        workThread = new HandlerThread("bbhint-work");
        workThread.start();
        work = new Handler(workThread.getLooper());

        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { main.post(new Runnable() { public void run() { stopSelf(); } }); }
        }, main);

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        sw = dm.widthPixels;
        sh = dm.heightPixels;

        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3);
        reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader r) {
                Image im = null;
                try { im = r.acquireLatestImage(); } catch (Exception ignored) { }
                if (im == null) return;
                synchronized (frameLock) {
                    if (held != null) held.close();
                    held = im;
                }
            }
        }, work);
        vdisplay = projection.createVirtualDisplay("bbhint", sw, sh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);

        addOverlay();
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "BB Hint", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("BB Hint aktif")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    // ---------- overlay ----------

    private void addOverlay() {
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;

        hintView = new HintView(this);
        WindowManager.LayoutParams hp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        hp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            hp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(hintView, hp);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setBackgroundColor(0xE6222222);
        Button hintBtn = makeBtn("Hint");
        autoBtn = makeBtn("Auto: mati");
        Button closeBtn = makeBtn("Tutup");
        panel.addView(hintBtn);
        panel.addView(autoBtn);
        panel.addView(closeBtn);
        hintBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { doHint(); } });
        autoBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleAuto(); } });
        closeBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { stopSelf(); } });

        WindowManager.LayoutParams pp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        pp.y = 40;
        wm.addView(panel, pp);
    }

    private Button makeBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0x00000000);
        return b;
    }

    private void setUiVisible(boolean v) {
        int vis = v ? View.VISIBLE : View.INVISIBLE;
        if (hintView != null) hintView.setVisibility(vis);
        if (panel != null) panel.setVisibility(vis);
    }

    private void toast(final String s) {
        main.post(new Runnable() { public void run() { Toast.makeText(CaptureService.this, s, Toast.LENGTH_SHORT).show(); } });
    }

    // ---------- hint ----------

    private void doHint() {
        if (autoOn) return;
        hintView.clear();
        setUiVisible(false);
        work.postDelayed(new Runnable() {
            @Override public void run() {
                final Analysis a = analyze();
                main.post(new Runnable() {
                    @Override public void run() {
                        setUiVisible(true);
                        if (a.error != null) toast(a.error);
                        else hintView.show(a.res, a.plan, a.pieces, a.slotOf);
                    }
                });
            }
        }, 350);
    }

    private Analysis analyze() {
        Analysis a = new Analysis();
        int[] wh = new int[2];
        int[] px = grabPixels(wh);
        if (px == null) { a.error = "Belum ada gambar layar, coba lagi"; return a; }
        Detector.Result r = Detector.detect(px, wh[0], wh[1]);
        if (r.error != null) { a.error = r.error; return a; }

        List<Piece> ps = new ArrayList<>();
        List<Integer> slots = new ArrayList<>();
        for (int s = 0; s < 3; s++) {
            if (r.slots[s] != null && r.slots[s].piece != null) {
                ps.add(r.slots[s].piece);
                slots.add(s);
            }
        }
        if (ps.isEmpty()) { a.error = "Blok di bawah tidak terbaca"; return a; }

        Piece[] arr = ps.toArray(new Piece[0]);
        Solver.Plan plan = Solver.solve(r.board, arr);
        if (plan.placed == 0) { a.error = "Tidak ada tempat yang muat"; return a; }

        a.res = r;
        a.plan = plan;
        a.pieces = arr;
        a.slotOf = new int[slots.size()];
        for (int i = 0; i < a.slotOf.length; i++) a.slotOf[i] = slots.get(i);
        return a;
    }

    /** Konversi frame terakhir ke 0xAARRGGBB. wh diisi lebar & tinggi. */
    private int[] grabPixels(int[] wh) {
        synchronized (frameLock) {
            if (held == null) return null;
            int iw = held.getWidth(), ih = held.getHeight();
            Image.Plane pl = held.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rs = pl.getRowStride();
            int[] px = new int[iw * ih];
            byte[] row = new byte[iw * 4];
            for (int y = 0; y < ih; y++) {
                buf.position(y * rs);
                buf.get(row, 0, iw * 4);
                int o = y * iw;
                for (int x = 0; x < iw; x++) {
                    int i = x * 4;
                    px[o + x] = 0xFF000000 | (row[i] & 255) << 16 | (row[i + 1] & 255) << 8 | (row[i + 2] & 255);
                }
            }
            wh[0] = iw;
            wh[1] = ih;
            return px;
        }
    }

    // ---------- auto ----------

    private void toggleAuto() {
        if (autoOn) {
            autoOn = false;
            return;
        }
        if (AutoService.get() == null) {
            toast("Aktifkan layanan aksesibilitas BB Hint dulu");
            return;
        }
        autoOn = true;
        autoBtn.setText("Auto: hidup");
        hintView.clear();
        autoThread = new Thread(new Runnable() { public void run() { autoLoop(); } });
        autoThread.start();
    }

    private void autoLoop() {
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        try {
            int fails = 0;
            while (autoOn) {
                main.post(new Runnable() { public void run() { setUiVisible(false); } });
                Thread.sleep(400);
                Analysis a = analyze();
                main.post(new Runnable() { public void run() { setUiVisible(true); } });
                if (a.error != null) {
                    if (++fails >= 3) { toast(a.error); break; }
                    Thread.sleep(900);
                    continue;
                }
                fails = 0;
                int offY = sp.getInt("offy", 0);
                AutoService svc = AutoService.get();
                if (svc == null) break;
                for (Solver.Move m : a.plan.moves) {
                    if (!autoOn) break;
                    Detector.Slot s = a.res.slots[a.slotOf[m.piece]];
                    Piece p = a.pieces[m.piece];
                    float sx = s.x + s.w / 2, sy = s.y + s.h / 2;
                    float ex = a.res.left + (m.c + p.w / 2f) * a.res.cell;
                    float ey = a.res.top + (m.r + p.h / 2f) * a.res.cell + offY;
                    svc.drag(sx, sy, ex, ey, 450);
                    Thread.sleep(700);
                }
                Thread.sleep(1400);
            }
        } catch (InterruptedException ignored) {
        } finally {
            autoOn = false;
            main.post(new Runnable() {
                public void run() {
                    if (autoBtn != null) autoBtn.setText("Auto: mati");
                    setUiVisible(true);
                }
            });
        }
    }

    @Override public void onDestroy() {
        autoOn = false;
        if (autoThread != null) autoThread.interrupt();
        try { if (hintView != null) wm.removeView(hintView); } catch (Exception ignored) { }
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) { }
        synchronized (frameLock) {
            if (held != null) { held.close(); held = null; }
        }
        if (vdisplay != null) vdisplay.release();
        if (reader != null) reader.close();
        if (projection != null) projection.stop();
        if (workThread != null) workThread.quitSafely();
        super.onDestroy();
    }
}
