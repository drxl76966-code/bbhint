package com.bbhint;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Cuma dipakai untuk satu hal: menyeret blok dari tray ke papan. */
public class AutoService extends AccessibilityService {
    private static volatile AutoService instance;

    public static AutoService get() { return instance; }

    @Override protected void onServiceConnected() { instance = this; }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    /** Blocking: jangan dipanggil dari main thread. */
    public boolean drag(float sx, float sy, float ex, float ey, long dur) {
        Path p = new Path();
        p.moveTo(sx, sy);
        p.lineTo(ex, ey);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, dur)).build();
        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] ok = {false};
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) { ok[0] = true; done.countDown(); }
            @Override public void onCancelled(GestureDescription d) { done.countDown(); }
        }, null);
        if (!sent) return false;
        try { done.await(dur + 2000, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return false; }
        return ok[0];
    }
}
