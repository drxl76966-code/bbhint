package com.bbhint;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 100;

    private TextView status;
    private EditText offset;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("BB Hint");
        title.setTextSize(24);
        title.setTextColor(0xFF111111);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextColor(0xFF444444);
        status.setPadding(0, dp(8), 0, dp(16));
        root.addView(status);

        root.addView(button("1. Izinkan tampil di atas aplikasi lain", new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        }));
        root.addView(button("2. Aktifkan aksesibilitas (hanya untuk Auto)", new View.OnClickListener() {
            public void onClick(View v) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
        }));
        root.addView(button("3. Mulai (izin rekam layar)", new View.OnClickListener() {
            public void onClick(View v) { start(); }
        }));

        TextView offLabel = new TextView(this);
        offLabel.setText("Geser titik lepas drag ke bawah/atas (px, boleh minus). Naikkan kalau blok mendarat terlalu tinggi.");
        offLabel.setTextSize(13);
        offLabel.setPadding(0, dp(20), 0, dp(4));
        root.addView(offLabel);

        offset = new EditText(this);
        offset.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        offset.setText(String.valueOf(prefs().getInt("offy", 0)));
        root.addView(offset);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        String s = "Overlay: " + (Settings.canDrawOverlays(this) ? "diizinkan" : "belum")
                + "\nAksesibilitas (Auto): " + (accessibilityOn() ? "aktif" : "belum");
        status.setText(s);
    }

    private boolean accessibilityOn() {
        String v = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return v != null && v.contains(getPackageName());
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan overlay dulu (langkah 1)", Toast.LENGTH_SHORT).show();
            return;
        }
        int off = 0;
        try { off = Integer.parseInt(offset.getText().toString().trim()); } catch (Exception ignored) { }
        prefs().edit().putInt("offy", off).apply();
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_CAPTURE) return;
        if (result != RESULT_OK || data == null) {
            Toast.makeText(this, "Izin rekam layar ditolak", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, CaptureService.class);
        svc.putExtra("code", result);
        svc.putExtra("data", data);
        startForegroundService(svc);
        moveTaskToBack(true);
    }

    private SharedPreferences prefs() { return getSharedPreferences("cfg", MODE_PRIVATE); }

    private Button button(String t, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(t);
        bt.setAllCaps(false);
        bt.setOnClickListener(l);
        return bt;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
