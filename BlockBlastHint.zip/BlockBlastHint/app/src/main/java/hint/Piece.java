package hint;

import java.util.*;

/** Satu blok: bentuk disimpan sebagai bitmask per baris (bit 0 = kolom paling kiri). */
public final class Piece {
    public final int h, w, cells;
    public final int[] rows;

    public Piece(int[] rows, int w) {
        this.rows = rows;
        this.h = rows.length;
        this.w = w;
        int n = 0;
        for (int r : rows) n += Integer.bitCount(r);
        this.cells = n;
    }

    /** Contoh: "XX/X." (baris dipisah '/'). */
    public static Piece parse(String s) {
        String[] p = s.split("/");
        int[] rows = new int[p.length];
        int w = 0;
        for (int i = 0; i < p.length; i++) {
            w = Math.max(w, p[i].length());
            for (int j = 0; j < p[i].length(); j++)
                if (p[i].charAt(j) == 'X') rows[i] |= 1 << j;
        }
        return new Piece(rows, w);
    }

    public boolean[][] grid() {
        boolean[][] g = new boolean[h][w];
        for (int i = 0; i < h; i++)
            for (int j = 0; j < w; j++) g[i][j] = (rows[i] >> j & 1) != 0;
        return g;
    }

    static Piece fromGrid(boolean[][] g) {
        int[] rows = new int[g.length];
        for (int i = 0; i < g.length; i++)
            for (int j = 0; j < g[i].length; j++) if (g[i][j]) rows[i] |= 1 << j;
        return new Piece(rows, g[0].length);
    }

    private Piece rotate() {
        boolean[][] g = grid();
        boolean[][] o = new boolean[w][h];
        for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) o[j][h - 1 - i] = g[i][j];
        return fromGrid(o);
    }

    private Piece mirror() {
        boolean[][] g = grid();
        boolean[][] o = new boolean[h][w];
        for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) o[i][w - 1 - j] = g[i][j];
        return fromGrid(o);
    }

    @Override public boolean equals(Object o) {
        return o instanceof Piece && ((Piece) o).w == w && Arrays.equals(((Piece) o).rows, rows);
    }
    @Override public int hashCode() { return Arrays.hashCode(rows) * 31 + w; }

    private static final String[] BASE = {
        "X", "XX", "XXX", "XXXX", "XXXXX", "XX/XX", "XXX/XXX", "XXX/XXX/XXX",
        "X./XX", "X../X../XXX", "X./X./XX", "XX./.XX", "XXX/.X.", "XX/X./X.",
        "X./.X"
    };

    /** Semua bentuk (termasuk rotasi & cermin) yang dipakai untuk menilai ruang tersisa. */
    public static List<Piece> library() {
        Set<Piece> set = new LinkedHashSet<>();
        for (String b : BASE) {
            Piece p = parse(b);
            for (int m = 0; m < 2; m++) {
                for (int r = 0; r < 4; r++) { set.add(p); p = p.rotate(); }
                p = p.mirror();
            }
        }
        return new ArrayList<>(set);
    }
}
