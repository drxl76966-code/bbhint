package hint;

/** Membaca papan 8x8 dan 3 blok dari piksel screenshot (format 0xAARRGGBB). */
public final class Detector {
    public static final class Slot {
        public Piece piece;          // null kalau slot kosong
        public float x, y, w, h;     // kotak blok di layar (px)
    }

    public static final class Result {
        public final int[] board = new int[8];
        public float left, top, cell; // pojok kiri-atas papan & ukuran satu kotak (px)
        public final Slot[] slots = new Slot[3];
        public String error;
    }

    private static final float TRAY_RATIO = 0.452f; // ukuran kotak blok di tray / kotak papan

    private static boolean dark(int p) {
        int r = p >> 16 & 255, g = p >> 8 & 255, b = p & 255;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mx < 100 && mx - mn < 45;
    }

    private static boolean colored(int p) {
        int r = p >> 16 & 255, g = p >> 8 & 255, b = p & 255;
        return Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) >= 50;
    }

    private static boolean filledCell(int[] px, int w, int cx, int cy, int rad) {
        long rs = 0, gs = 0, bs = 0; int n = 0;
        for (int y = cy - rad; y <= cy + rad; y += 2)
            for (int x = cx - rad; x <= cx + rad; x += 2) {
                int p = px[y * w + x];
                rs += p >> 16 & 255; gs += p >> 8 & 255; bs += p & 255; n++;
            }
        int r = (int) (rs / n), g = (int) (gs / n), b = (int) (bs / n);
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mx - mn > 50 || mx > 120;
    }

    public static Result detect(int[] px, int w, int h) {
        Result res = new Result();
        int y0 = (int) (h * 0.12), y1 = (int) (h * 0.85);
        int top = -1, bottom = -1, needRow = (int) (w * 0.30 / 3);
        for (int y = y0; y < y1; y++) {
            int n = 0;
            for (int x = 0; x < w; x += 3) if (dark(px[y * w + x])) n++;
            if (n >= needRow) { if (top < 0) top = y; bottom = y; }
        }
        if (top < 0) { res.error = "Papan tidak ketemu di layar"; return res; }
        int left = -1, right = -1, needCol = (int) ((bottom - top) * 0.30 / 3);
        for (int x = 0; x < w; x++) {
            int n = 0;
            for (int y = top; y <= bottom; y += 3) if (dark(px[y * w + x])) n++;
            if (n >= needCol) { if (left < 0) left = x; right = x; }
        }
        int bw = right - left + 1, bh = bottom - top + 1;
        if (left < 0 || Math.abs(bw - bh) > 0.06f * Math.max(bw, bh)) {
            res.error = "Papan tidak ketemu di layar";
            return res;
        }
        res.left = left; res.top = top;
        res.cell = (bw + bh) / 16f;

        int rad = Math.max(2, (int) (res.cell * 0.15f));
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                int cx = (int) (left + (c + 0.5f) * res.cell), cy = (int) (top + (r + 0.5f) * res.cell);
                if (filledCell(px, w, cx, cy, rad)) res.board[r] |= 1 << c;
            }

        int ty0 = Math.min(h - 1, (int) (bottom + h * 0.02)), ty1 = (int) (h * 0.9);
        float ps = res.cell * TRAY_RATIO;
        for (int s = 0; s < 3; s++) {
            int xa = s * w / 3, xb = (s + 1) * w / 3;
            int minX = w, maxX = -1, minY = h, maxY = -1, cnt = 0;
            for (int y = ty0; y < ty1; y += 2)
                for (int x = xa; x < xb; x += 2)
                    if (colored(px[y * w + x])) {
                        cnt++;
                        if (x < minX) minX = x; if (x > maxX) maxX = x;
                        if (y < minY) minY = y; if (y > maxY) maxY = y;
                    }
            Slot slot = new Slot();
            res.slots[s] = slot;
            if (cnt < 40) continue;
            float sw = maxX - minX + 2, sh = maxY - minY + 2;
            int cols = Math.max(1, Math.min(5, Math.round(sw / ps)));
            int rows = Math.max(1, Math.min(5, Math.round(sh / ps)));
            float csx = sw / cols, csy = sh / rows;
            int[] pr = new int[rows];
            int rr = Math.max(1, (int) (Math.min(csx, csy) * 0.15f));
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++) {
                    int cx = (int) (minX + (c + 0.5f) * csx), cy = (int) (minY + (r + 0.5f) * csy);
                    int hit = 0, tot = 0;
                    for (int y = cy - rr; y <= cy + rr; y++)
                        for (int x = cx - rr; x <= cx + rr; x++) { tot++; if (colored(px[y * w + x])) hit++; }
                    if (hit * 2 >= tot) pr[r] |= 1 << c;
                }
            slot.piece = new Piece(pr, cols);
            slot.x = minX; slot.y = minY; slot.w = sw; slot.h = sh;
        }
        return res;
    }
}
